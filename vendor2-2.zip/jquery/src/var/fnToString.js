define( [
	"./hasOwn"
], function( hasOwn ) {
	"use strict";

	return hasOwn.toString;
} );
