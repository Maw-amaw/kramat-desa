<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Kesehatan */

$this->title = $model->nama;
$this->params['breadcrumbs'][] = ['label' => 'Kesehatans', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="kesehatan-view">

    <h2>apakah anda tidak ingin merubah data ?</h2>

    <p>
    <a class="btn btn-danger" href="http://localhost/yii.framework/amaw/frontend/web/" role="button">back</a>
    </p>



</div>
