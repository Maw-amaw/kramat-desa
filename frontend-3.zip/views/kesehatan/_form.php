<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use frontend\models\Companies;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $model app\models\Kesehatan */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="kesehatan-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nama')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'rt')->dropDownList(['1'=>'1','2'=>'2','3'=>'3']) ?>
    
    <?= $form->field($model, 'dusun')->dropDownList(['Kramat'=>'Kramat','Ngablak'=>'Ngablak','Cekel'=>'Cekel']) ?>
    

    <div class="form-group">
        <?= Html::submitButton('kirim', ['class' => 'btn btn-primary']) ?>
        <a class="btn btn-danger" href="https://api.whatsapp.com/send?phone=088803391301&text=assalamualaikum20%saya20%keadaan20%darurat" role="button">darurat</a>
    </div>

    <?php ActiveForm::end(); ?>

</div>
