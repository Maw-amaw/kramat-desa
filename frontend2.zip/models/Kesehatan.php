<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "kesehatan".
 *
 * @property string $nama
 * @property int $rt
 * @property string $dusun
 */
class Kesehatan extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kesehatan';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama', 'rt', 'dusun'], 'required'],
            [['rt'], 'integer'],
            [['nama'], 'string', 'max' => 25],
            [['dusun'], 'string', 'max' => 30],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'nama' => 'Nama',
            'rt' => 'Rt',
            'dusun' => 'Dusun',
        ];
    }
}
