<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "kebersihan".
 *
 * @property int $rt
 * @property string $dusun
 */
class kebersihan extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kebersihan';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['rt', 'dusun'], 'required'],
            [['rt'], 'integer'],
            [['dusun'], 'string', 'max' => 11],
            [['rt'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'rt' => 'Rt',
            'dusun' => 'Dusun',
        ];
    }
}
