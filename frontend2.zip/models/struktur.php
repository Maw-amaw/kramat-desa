<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "struktur".
 *
 * @property int $id
 * @property string $nama
 * @property string $jabatan
 * @property string $alamat
 * @property int $no_wa
 */
class struktur extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'struktur';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'nama', 'jabatan', 'alamat', 'no_wa'], 'required'],
            [['id', 'no_wa'], 'integer'],
            [['nama', 'jabatan'], 'string', 'max' => 225],
            [['alamat'], 'string', 'max' => 255],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nama' => 'Nama',
            'jabatan' => 'Jabatan',
            'alamat' => 'Alamat',
            'no_wa' => 'No Wa',
        ];
    }
}
